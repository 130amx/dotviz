package com.example.dotviz

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.TrafficStats
import android.os.PowerManager
import java.util.Calendar
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private fun mono(): Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

private fun textPaint(color: Int, px: Float, align: Paint.Align = Paint.Align.LEFT): Paint {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    p.textSize = px
    p.typeface = mono()
    p.textAlign = align
    return p
}

/** 4) Terminal con texto que se escribe solo y glitches ocasionales. */
object TerminalRenderer : Renderer {
    override val intervalMs = 250L
    private const val GLITCH = "#%@&$?!"

    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, true)
        val cal = Calendar.getInstance()
        val bat = Stats.battery(ctx)
        val lines = mutableListOf(
            "NOTHING//TERM v1.0",
            "> BAT ${bat.level}%" + (if (bat.charging) " CHG" else ""),
            "> NET ${Stats.netLabel(ctx)}",
            "> MEM ${(Stats.ramPct(ctx) * 100).roundToInt()}%",
            String.format("> TIME %02d:%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND)),
            "> UNLOCKS ${Stats.unlocks(ctx)}"
        )
        val total = lines.sumOf { it.length }
        val step = ((now / 80L) % (total + 60).toLong()).toInt()
        val revealed = min(total, step)
        if (revealed >= total && (now / 500L) % 2L == 0L) {
            lines[lines.size - 1] = lines.last() + "_"
        }
        val chars = lines.map { it.toCharArray() }
        if ((now / 300L) % 23L == 0L) {
            val li = ((now / 300L) % chars.size).toInt()
            if (chars[li].isNotEmpty()) {
                chars[li][((now / 300L) % chars[li].size).toInt()] = GLITCH[((now / 300L) % GLITCH.length).toInt()]
            }
        }
        val margin = size * 0.09f
        val px = size * 0.058f
        val p = textPaint(Gfx.gray(0xE0), px)
        var remaining = revealed
        var y = margin + px * 1.4f
        for ((i, ch) in chars.withIndex()) {
            val n = min(ch.size, max(0, remaining))
            remaining -= ch.size
            p.color = if (i == 0) Gfx.gray(0x88) else Gfx.gray(0xE0)
            c.drawText(String(ch, 0, n), margin, y, p)
            y += px * 1.55f
        }
        if ((now / 1000L) % 2L == 0L) {
            val d = Paint(Paint.ANTI_ALIAS_FLAG)
            d.color = Gfx.RED
            c.drawCircle(size - margin - size * 0.03f, margin + size * 0.03f, size * 0.022f, d)
        }
        return bmp
    }
}

/** 5) HUD de sistema con barras segmentadas. */
object HudRenderer : Renderer {
    override val intervalMs = 2000L

    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, true)
        val bat = Stats.battery(ctx)
        val ram = Stats.ramPct(ctx)
        val sto = Stats.storagePct()
        val tmp = ((bat.tempC - 20f) / 30f).coerceIn(0f, 1f)

        val margin = size * 0.09f
        val title = textPaint(Gfx.gray(0x88), size * 0.05f)
        c.drawText("SYS//HUD", margin, margin + size * 0.05f, title)

        class Row(val label: String, val pct: Float, val value: String, val bad: Boolean)
        val rows = listOf(
            Row("BAT", bat.level / 100f, "${bat.level}%", bat.level <= 15 && !bat.charging),
            Row("RAM", ram, "${(ram * 100).roundToInt()}%", ram >= 0.9f),
            Row("STO", sto, "${(sto * 100).roundToInt()}%", sto >= 0.9f),
            Row("TMP", tmp, String.format("%.0fC", bat.tempC), bat.tempC >= 42f)
        )
        val lab = textPaint(Gfx.gray(0xDD), size * 0.05f)
        val value = textPaint(Gfx.gray(0xDD), size * 0.05f, Paint.Align.RIGHT)
        val seg = Paint(Paint.ANTI_ALIAS_FLAG)
        val n = 14
        val barX = size * 0.27f
        val barW = size * 0.47f
        val segW = barW / n
        var y = size * 0.30f
        for (row in rows) {
            c.drawText(row.label, margin, y + size * 0.02f, lab)
            c.drawText(row.value, size - margin, y + size * 0.02f, value)
            val filled = (row.pct * n).roundToInt().coerceIn(0, n)
            for (i in 0 until n) {
                seg.color = if (i < filled) (if (row.bad) Gfx.RED else Gfx.gray(0xF0)) else Gfx.gray(0x2E)
                val x = barX + i * segW
                c.drawRect(RectF(x, y - size * 0.03f, x + segW * 0.72f, y + size * 0.03f), seg)
            }
            y += size * 0.17f
        }
        return bmp
    }
}

/** 6) Reloj de puntos + cuenta atrás T-MINUS + línea de escaneo. */
object ClockRenderer : Renderer {
    override val intervalMs = 500L

    private val F = arrayOf(
        arrayOf("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
        arrayOf("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
        arrayOf("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
        arrayOf("11110", "00001", "00001", "01110", "00001", "00001", "11110"),
        arrayOf("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
        arrayOf("11111", "10000", "11110", "00001", "00001", "10001", "01110"),
        arrayOf("00110", "01000", "10000", "11110", "10001", "10001", "01110"),
        arrayOf("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
        arrayOf("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
        arrayOf("01110", "10001", "10001", "01111", "00001", "00010", "01100")
    )
    private val starts = intArrayOf(0, 6, 14, 20)

    private fun lit(col: Int, row: Int, d: IntArray, colon: Boolean): Boolean {
        for (i in 0..3) {
            val x = col - starts[i]
            if (x in 0..4) return F[d[i]][row][x] == '1'
        }
        if (col == 12) return colon && (row == 2 || row == 4)
        return false
    }

    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, false)
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val s = cal.get(Calendar.SECOND)
        val digits = intArrayOf(h / 10, h % 10, m / 10, m % 10)
        val colon = (now / 500L) % 2L == 0L
        val scan = ((now / 120L) % 40L).toInt()

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val margin = size * 0.06f
        val cell = (size - 2 * margin) / 25f
        val r = cell * 0.36f
        val y0 = size * 0.17f
        for (row in 0 until 7) {
            for (col in 0 until 25) {
                p.color = when {
                    lit(col, row, digits, colon) -> Gfx.gray(255)
                    col == scan -> Gfx.gray(0x5A)
                    else -> Gfx.gray(0x26)
                }
                c.drawCircle(margin + cell * (col + 0.5f), y0 + cell * (row + 0.5f), r, p)
            }
        }
        val sec = s * 25 / 60
        for (col in 0 until 25) {
            p.color = when {
                col == sec -> Gfx.RED
                col < sec -> Gfx.gray(0x9A)
                else -> Gfx.gray(0x26)
            }
            c.drawCircle(margin + cell * (col + 0.5f), y0 + cell * 9.5f, r * 0.8f, p)
        }

        val target = if (Config.EVENT_EPOCH_MS > 0L) Config.EVENT_EPOCH_MS else
            Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        var left = max(0L, (target - now) / 1000L)
        val days = left / 86400L
        left %= 86400L
        val txt = (if (days > 0) "${days}D " else "") +
                String.format("%02d:%02d:%02d", left / 3600L, (left % 3600L) / 60L, left % 60L)
        c.drawText("T-MINUS", margin + size * 0.02f, size * 0.74f, textPaint(Gfx.gray(0x88), size * 0.045f))
        c.drawText(txt, margin + size * 0.02f, size * 0.84f, textPaint(Gfx.gray(0xF0), size * 0.08f))
        c.drawText(Config.EVENT_NAME, size - margin - size * 0.02f, size * 0.74f,
            textPaint(Gfx.RED, size * 0.045f, Paint.Align.RIGHT))
        return bmp
    }
}

/** 8) Monitor de red tipo osciloscopio (rojo = pico de tráfico). */
object NetRenderer : Renderer {
    override val intervalMs = 700L
    private val rx = FloatArray(16)
    private val tx = FloatArray(16)
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L
    private var rxRate = 0f
    private var txRate = 0f

    private fun level(rate: Float) = (log10(1f + rate / 1024f) / log10(1f + 20000f) * 12f).coerceIn(0f, 12f)

    private fun fmt(rate: Float): String =
        if (rate >= 1024f * 1024f) String.format("%.1f MB/s", rate / (1024f * 1024f))
        else String.format("%.0f KB/s", rate / 1024f)

    @Synchronized
    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val nr = TrafficStats.getTotalRxBytes()
        val nt = TrafficStats.getTotalTxBytes()
        if (lastT != 0L && nr >= 0 && nt >= 0) {
            val dt = (now - lastT) / 1000f
            if (dt > 0.1f) {
                rxRate = max(0f, (nr - lastRx) / dt)
                txRate = max(0f, (nt - lastTx) / dt)
            }
        }
        lastRx = nr; lastTx = nt; lastT = now
        for (i in 0 until 15) { rx[i] = rx[i + 1]; tx[i] = tx[i + 1] }
        rx[15] = level(rxRate)
        tx[15] = level(txRate)

        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val margin = size * 0.08f
        val cell = (size - 2 * margin) / 16f
        val r = cell * 0.34f
        val y0 = size * 0.09f
        for (col in 0 until 16) {
            val lit = rx[col].roundToInt()
            val txRow = tx[col].roundToInt() - 1
            for (row in 0 until 12) {
                var g = 0x26
                if (row < lit) {
                    val depth = lit - 1 - row
                    g = when (depth) { 0 -> 255; 1 -> 160; 2 -> 110; else -> 70 }
                    p.color = if (depth == 0 && lit >= 11) Gfx.RED else Gfx.gray(g)
                } else p.color = Gfx.gray(g)
                if (row == txRow && row >= lit) p.color = Gfx.gray(0xB0)
                c.drawCircle(margin + cell * (col + 0.5f), y0 + cell * (11 - row + 0.5f), r, p)
            }
        }
        val ty = y0 + cell * 12f + size * 0.085f
        c.drawText("RX " + fmt(rxRate), margin, ty, textPaint(Gfx.gray(0xEE), size * 0.055f))
        c.drawText("TX " + fmt(txRate), margin, ty + size * 0.085f, textPaint(Gfx.gray(0x99), size * 0.055f))
        return bmp
    }
}

/** 9) Estado: ONLINE / OFFLINE / LOW POWER + desbloqueos del día. */
object StatusRenderer : Renderer {
    override val intervalMs = 1000L

    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, true)
        val online = Stats.isOnline(ctx)
        val bat = Stats.battery(ctx)
        val saver = ctx.getSystemService(PowerManager::class.java).isPowerSaveMode
        val low = (bat.level <= 15 && !bat.charging) || saver
        val label = when {
            !online -> "OFFLINE"
            low -> "LOW POWER"
            else -> "ONLINE"
        }
        val alert = label != "ONLINE"
        val blink = (now / 1000L) % 2L == 0L
        val margin = size * 0.09f

        val d = Paint(Paint.ANTI_ALIAS_FLAG)
        d.color = if (alert) Gfx.RED else Gfx.gray(255)
        if (!alert || blink) c.drawCircle(margin + size * 0.02f, margin + size * 0.04f, size * 0.025f, d)
        c.drawText("STATUS", margin + size * 0.07f, margin + size * 0.06f, textPaint(Gfx.gray(0x88), size * 0.05f))

        val big = textPaint(Gfx.gray(255), size * 0.16f, Paint.Align.CENTER)
        val maxW = size - 2 * margin
        val w = big.measureText(label)
        if (w > maxW) big.textSize = big.textSize * maxW / w
        c.drawText(label, size / 2f, size * 0.52f, big)

        val line = Paint(Paint.ANTI_ALIAS_FLAG)
        line.color = Gfx.gray(0x44)
        c.drawRect(RectF(margin, size * 0.64f, size - margin, size * 0.64f + 2f), line)
        val small = textPaint(Gfx.gray(0xAA), size * 0.055f)
        c.drawText("UNLOCKS ${Stats.unlocks(ctx)}", margin, size * 0.76f, small)
        c.drawText("BAT ${bat.level}%" + (if (bat.charging) " CHG" else ""), margin, size * 0.86f, small)
        return bmp
    }
}
