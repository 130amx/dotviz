package com.example.dotviz

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

private const val OFF = 0x26

/** 1) Matriz 16x16 reactiva a la música (el doble de puntos por lado). */
object AudioRenderer : Renderer {
    override val intervalMs = 60L
    private var idleDrawn = false
    private val levels = intArrayOf(255, 205, 150, 125, 105, 90, 78, 70, 64, 60, 58, 56, 54, 52, 50, 50)

    override fun shouldDraw() = !(Audio.silent() && idleDrawn)

    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val silent = Audio.silent()
        idleDrawn = silent
        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val margin = size * 0.08f
        val cell = (size - 2 * margin) / 16f
        val r = cell * 0.34f
        for (col in 0 until 16) {
            val lit = if (silent) 0 else Audio.bands[col].roundToInt().coerceIn(0, 16)
            for (row in 0 until 16) {
                val g = if (row < lit) levels[(lit - 1 - row).coerceIn(0, 15)] else OFF
                p.color = Gfx.gray(g)
                c.drawCircle(margin + cell * (col + 0.5f), size - margin - cell * (row + 0.5f), r, p)
            }
        }
        return bmp
    }
}

/** 2) Lluvia de código en puntos, reactiva a la música. */
object RainRenderer : Renderer {
    override val intervalMs = 80L
    private val head = FloatArray(16) { -((it * 5) % 11).toFloat() }
    private var last = 0L
    private var idleDrawn = false

    override fun shouldDraw() = !(Audio.silent() && idleDrawn)

    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val silent = Audio.silent()
        idleDrawn = silent
        val dt = if (last == 0L) 0.08f else ((now - last) / 1000f).coerceIn(0f, 0.3f)
        last = now
        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val margin = size * 0.08f
        val cell = (size - 2 * margin) / 16f
        val r = cell * 0.34f
        for (col in 0 until 16) {
            val b = Audio.bands[col]
            val trail = 3f + b / 16f * 8f
            if (!silent) {
                head[col] += (3f + b * 0.8f) * dt
                if (head[col] - trail > 16f) head[col] = -Random.nextFloat() * 8f
            }
            for (row in 0 until 16) {
                val d = head[col] - row
                var color = Gfx.gray(OFF)
                if (!silent && d >= 0f && d < trail) {
                    color = if (d < 1f) {
                        if (b >= 13.5f) Gfx.RED else Gfx.gray(255)
                    } else {
                        Gfx.gray(max(45, (255 * (1f - d / trail)).toInt()))
                    }
                }
                p.color = color
                c.drawCircle(margin + cell * (col + 0.5f), margin + cell * (row + 0.5f), r, p)
            }
        }
        return bmp
    }
}

/** 3) Radar: cada notificación pendiente es un contacto (rojo = la más reciente). */
object RadarRenderer : Renderer {
    override val intervalMs = 100L

    private fun h(i: Int): Float {
        var x = i * 374761393 + 668265263
        x = (x xor (x ushr 13)) * 1274126177.toInt()
        x = x xor (x ushr 16)
        return (x and 0xFFFF) / 65535f
    }

    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val two = (2 * PI).toFloat()
        val sweep = (now % 3000L) / 3000f * two
        val n = if (Stats.notifLinked) minOf(Stats.notifCount, 12) else 5
        val blipCol = IntArray(n)
        val blipRow = IntArray(n)
        for (i in 0 until n) {
            val a = h(i * 2 + 1) * two
            val rad = 2.5f + h(i * 2 + 2) * 4.8f
            blipCol[i] = (7.5f + rad * cos(a)).roundToInt().coerceIn(0, 15)
            blipRow[i] = (7.5f + rad * sin(a)).roundToInt().coerceIn(0, 15)
        }
        val margin = size * 0.08f
        val cell = (size - 2 * margin) / 16f
        val r = cell * 0.34f
        for (col in 0 until 16) {
            for (row in 0 until 16) {
                val dx = col - 7.5f
                val dy = row - 7.5f
                val dist = hypot(dx, dy)
                if (dist > 7.7f) continue
                var ang = atan2(dy, dx)
                if (ang < 0) ang += two
                var delta = (sweep - ang) % two
                if (delta < 0) delta += two
                var g = 0x2A
                if (abs(dist - 3f) < 0.5f || abs(dist - 6f) < 0.5f) g = 0x38
                if (delta < 1.4f) g = max(g, (200 * (1f - delta / 1.4f)).toInt())
                var color = Gfx.gray(g)
                for (i in 0 until n) {
                    if (blipCol[i] == col && blipRow[i] == row && delta < 3.2f) {
                        val k = 1f - delta / 3.2f
                        color = if (i == 0) Gfx.scale(Gfx.RED, 0.3f + 0.7f * k)
                                else Gfx.gray((120 + 135 * k).toInt())
                    }
                }
                p.color = color
                c.drawCircle(margin + cell * (col + 0.5f), margin + cell * (row + 0.5f), r, p)
            }
        }
        return bmp
    }
}

/** 7) Ciudad nocturna: las ventanas se encienden según la hora real. */
object SkylineRenderer : Renderer {
    override val intervalMs = 4000L
    private val heights: IntArray = Random(42).let { rnd -> IntArray(16) { 4 + rnd.nextInt(9) } }

    private fun h(i: Int): Float {
        var x = i * 374761393 + 668265263
        x = (x xor (x ushr 13)) * 1274126177.toInt()
        x = x xor (x ushr 16)
        return (x and 0xFFFF) / 65535f
    }

    override fun render(ctx: Context, size: Int, now: Long): Bitmap {
        val bmp = Gfx.bitmap(size)
        val c = Canvas(bmp)
        Gfx.panel(c, size, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = hour >= 19 || hour < 6
        val prob = if (night) 0.55f else 0.12f
        val slot = (now / 4000L).toInt()
        var tall = 0
        for (i in 1 until 16) if (heights[i] > heights[tall]) tall = i
        val margin = size * 0.08f
        val cell = (size - 2 * margin) / 16f
        val r = cell * 0.34f
        for (col in 0 until 16) {
            for (row in 0 until 16) { // row 0 = abajo
                var color = Gfx.gray(0x22)
                if (row < heights[col]) {
                    val k = col * 31 + row
                    var lit = h(k) < prob
                    if (h(k + slot * 977) < 0.03f) lit = !lit
                    color = if (lit) Gfx.gray(if (h(k + 5) > 0.5f) 235 else 185) else Gfx.gray(0x3A)
                } else if (col == tall && row == heights[col] && (now / 1000L) % 2L == 0L) {
                    color = Gfx.RED
                }
                p.color = color
                c.drawCircle(margin + cell * (col + 0.5f), size - margin - cell * (row + 0.5f), r, p)
            }
        }
        return bmp
    }
}
