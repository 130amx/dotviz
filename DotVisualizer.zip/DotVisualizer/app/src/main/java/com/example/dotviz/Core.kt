package com.example.dotviz

import android.app.ActivityManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ajustes que puedes cambiar. */
object Config {
    /** Fecha del evento para la cuenta atrás (milisegundos epoch). 0 = hasta medianoche. */
    const val EVENT_EPOCH_MS = 0L
    const val EVENT_NAME = "EOD"
}

interface Renderer {
    val intervalMs: Long
    fun shouldDraw(): Boolean = true
    fun render(ctx: Context, size: Int, now: Long): Bitmap
}

object Audio {
    const val N = 16
    val bands = FloatArray(N)
    fun silent() = bands.all { it < 0.3f }
}

object Gfx {
    val RED = Color.rgb(0xD7, 0x19, 0x21)
    val PANEL = Color.rgb(0x1B, 0x1B, 0x1D)

    fun gray(g: Int): Int { val v = g.coerceIn(0, 255); return Color.rgb(v, v, v) }

    fun scale(c: Int, k: Float): Int {
        val f = k.coerceIn(0f, 1f)
        return Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())
    }

    fun bitmap(size: Int): Bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)

    fun panel(c: Canvas, size: Int, cut: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = PANEL
        val s = size.toFloat()
        if (!cut) {
            c.drawRoundRect(RectF(0f, 0f, s, s), s * 0.17f, s * 0.17f, p)
        } else {
            val k = s * 0.10f
            val path = Path()
            path.moveTo(0f, 0f)
            path.lineTo(s - k, 0f)
            path.lineTo(s, k)
            path.lineTo(s, s)
            path.lineTo(k, s)
            path.lineTo(0f, s - k)
            path.close()
            c.drawPath(path, p)
        }
    }
}

object Stats {
    @Volatile var notifCount = 0
    @Volatile var notifLinked = false

    data class Bat(val level: Int, val charging: Boolean, val tempC: Float)

    fun battery(ctx: Context): Bat {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        return Bat(if (scale > 0) level * 100 / scale else level, charging, temp)
    }

    fun ramPct(ctx: Context): Float {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return if (mi.totalMem > 0) 1f - mi.availMem / mi.totalMem.toFloat() else 0f
    }

    fun storagePct(): Float {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        return if (total > 0) 1f - free / total.toFloat() else 0f
    }

    fun isOnline(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(n) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun netLabel(ctx: Context): String {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork ?: return "OFFLINE"
        val caps = cm.getNetworkCapabilities(n) ?: return "OFFLINE"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELL"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETH"
            else -> "LINK"
        }
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun unlocks(ctx: Context): Int {
        val p = ctx.getSharedPreferences("stats", Context.MODE_PRIVATE)
        return if (p.getString("day", "") == today()) p.getInt("count", 0) else 0
    }

    fun addUnlock(ctx: Context) {
        val p = ctx.getSharedPreferences("stats", Context.MODE_PRIVATE)
        val t = today()
        val c = if (p.getString("day", "") == t) p.getInt("count", 0) else 0
        p.edit().putString("day", t).putInt("count", c + 1).apply()
    }
}

abstract class BaseWidget : AppWidgetProvider() {
    abstract val renderer: Renderer

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        for (id in ids) {
            val rv = RemoteViews(context.packageName, R.layout.widget_visualizer)
            try {
                rv.setImageViewBitmap(R.id.img, renderer.render(context, Registry.SIZE, System.currentTimeMillis()))
            } catch (e: Exception) { e.printStackTrace() }
            rv.setOnClickPendingIntent(R.id.img, open)
            manager.updateAppWidget(id, rv)
        }
    }
}

class AudioWidget : BaseWidget() { override val renderer: Renderer get() = AudioRenderer }
class RainWidget : BaseWidget() { override val renderer: Renderer get() = RainRenderer }
class RadarWidget : BaseWidget() { override val renderer: Renderer get() = RadarRenderer }
class TerminalWidget : BaseWidget() { override val renderer: Renderer get() = TerminalRenderer }
class HudWidget : BaseWidget() { override val renderer: Renderer get() = HudRenderer }
class ClockWidget : BaseWidget() { override val renderer: Renderer get() = ClockRenderer }
class SkylineWidget : BaseWidget() { override val renderer: Renderer get() = SkylineRenderer }
class NetWidget : BaseWidget() { override val renderer: Renderer get() = NetRenderer }
class StatusWidget : BaseWidget() { override val renderer: Renderer get() = StatusRenderer }

object Registry {
    const val SIZE = 360
    val entries: List<Pair<Class<out BaseWidget>, Renderer>> = listOf(
        AudioWidget::class.java to AudioRenderer,
        RainWidget::class.java to RainRenderer,
        RadarWidget::class.java to RadarRenderer,
        TerminalWidget::class.java to TerminalRenderer,
        HudWidget::class.java to HudRenderer,
        ClockWidget::class.java to ClockRenderer,
        SkylineWidget::class.java to SkylineRenderer,
        NetWidget::class.java to NetRenderer,
        StatusWidget::class.java to StatusRenderer
    )
}
