package com.example.dotviz

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS

        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) {
            launch()
        } else {
            requestPermissions(perms.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launch()
        } else {
            Toast.makeText(this, "Se necesita el permiso de audio", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun launch() {
        startForegroundService(Intent(this, VisualizerService::class.java))
        Toast.makeText(this, "Widgets activos", Toast.LENGTH_SHORT).show()

        // El radar usa las notificaciones: pedimos el acceso una sola vez.
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val prefs = getSharedPreferences("stats", MODE_PRIVATE)
        if (!enabled && !prefs.getBoolean("asked_notif", false)) {
            prefs.edit().putBoolean("asked_notif", true).apply()
            Toast.makeText(this, "Activa Dot Visualizer para que el radar vea tus notificaciones", Toast.LENGTH_LONG).show()
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (_: Exception) {}
        }
        finish()
    }
}
