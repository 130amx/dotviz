package com.example.dotviz

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS

        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) {
            askProjection()
        } else {
            requestPermissions(perms.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            askProjection()
        } else {
            Toast.makeText(this, "Se necesita el permiso de audio", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun askProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, VisualizerService::class.java)
                .putExtra(VisualizerService.EXTRA_CODE, resultCode)
                .putExtra(VisualizerService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "Visualizador activo", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
