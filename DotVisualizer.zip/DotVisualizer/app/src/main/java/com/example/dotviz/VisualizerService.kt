package com.example.dotviz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.pow

class VisualizerService : Service() {

    companion object { const val ACTION_STOP = "com.example.dotviz.STOP" }

    private var viz: Visualizer? = null
    private val bands = FloatArray(8)
    private var lastPush = 0L
    private var idleDrawn = false

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("viz", "Visualizer", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, VisualizerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "viz")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Visualizador activo")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Detener", stopPi
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (viz == null) startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        try {
            viz = Visualizer(0).apply { // sesión 0 = mezcla global, sin diálogo de captura
                enabled = false
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray?, r: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                        if (fft != null) process(fft, rate)
                    }
                }, Visualizer.getMaxCaptureRate(), false, true)
                enabled = true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            stopSelf()
        }
    }

    private fun process(fft: ByteArray, rateMilliHz: Int) {
        val sampleRate = rateMilliHz / 1000f
        val binHz = sampleRate / fft.size
        val numBins = fft.size / 2
        val fMin = 40f
        val fMax = minOf(12000f, sampleRate / 2f - 1f)

        for (i in 0 until 8) {
            val lo = fMin * (fMax / fMin).pow(i / 8f)
            val hi = fMin * (fMax / fMin).pow((i + 1) / 8f)
            val kLo = (lo / binHz).toInt().coerceIn(1, numBins - 1)
            val kHi = (hi / binHz).toInt().coerceIn(kLo, numBins - 1)

            var peak = 0f
            for (k in kLo..kHi) {
                peak = maxOf(peak, hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat()))
            }
            var v = log10(1f + peak) / log10(1f + 150f)
            v = (v * (1f + i * 0.07f)).coerceIn(0f, 1f)
            v = v * v * 1.1f
            val target = (v * 8f).coerceIn(0f, 8f)

            bands[i] = if (target > bands[i]) bands[i] + (target - bands[i]) * 0.65f
                       else bands[i] * 0.86f
        }

        val now = SystemClock.uptimeMillis()
        if (now - lastPush < 60) return
        val silent = bands.all { it < 0.3f }
        if (silent && idleDrawn) return
        lastPush = now
        idleDrawn = silent
        if (VisualizerWidget.hasWidgets(this)) {
            VisualizerWidget.push(this, if (silent) FloatArray(8) else bands)
        }
    }

    override fun onDestroy() {
        viz?.apply { enabled = false; release() }
        viz = null
        VisualizerWidget.push(this, FloatArray(8))
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
