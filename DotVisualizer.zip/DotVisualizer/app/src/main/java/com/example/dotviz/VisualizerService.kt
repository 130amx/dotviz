package com.example.dotviz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.widget.RemoteViews
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.pow

class VisualizerService : Service() {

    companion object { const val ACTION_STOP = "com.example.dotviz.STOP" }

    private var viz: Visualizer? = null
    private val lastDraw = HashMap<Class<*>, Long>()
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private var ticking = false

    private val unlockRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { Stats.addUnlock(c) }
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            val next = try { tick() } catch (e: Exception) { e.printStackTrace(); 500L }
            handler.postDelayed(this, next)
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("viz", "Cyber widgets", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, VisualizerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "viz")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Widgets activos")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Detener", stopPi
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1, n)

        val f = IntentFilter(Intent.ACTION_USER_PRESENT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(unlockRx, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(unlockRx, f)

        thread = HandlerThread("viz-tick").also { it.start() }
        handler = Handler(thread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (viz == null) startCapture()
        if (!ticking) { ticking = true; handler.post(tickRunnable) }
        return START_STICKY
    }

    /** Dibuja los widgets que existan; devuelve cuánto esperar hasta el siguiente ciclo. */
    private fun tick(): Long {
        val now = System.currentTimeMillis()
        val mgr = AppWidgetManager.getInstance(this)
        var minInterval = 1000L
        for ((cls, r) in Registry.entries) {
            val ids = mgr.getAppWidgetIds(ComponentName(this, cls))
            if (ids.isEmpty()) continue
            minInterval = minOf(minInterval, r.intervalMs)
            val last = lastDraw[cls] ?: 0L
            if (now - last < r.intervalMs) continue
            if (!r.shouldDraw()) continue
            lastDraw[cls] = now
            try {
                val rv = RemoteViews(packageName, R.layout.widget_visualizer)
                rv.setImageViewBitmap(R.id.img, r.render(applicationContext, Registry.SIZE, now))
                mgr.partiallyUpdateAppWidget(ids, rv)
            } catch (e: Exception) { e.printStackTrace() }
        }
        return maxOf(40L, minInterval)
    }

    private fun startCapture() {
        try {
            viz = Visualizer(0).apply { // sin diálogo de captura de pantalla
                enabled = false
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray?, r: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                        if (fft != null) process(fft, rate)
                    }
                }, Visualizer.getMaxCaptureRate(), false, true)
                enabled = true
            }
        } catch (e: Exception) {
            e.printStackTrace() // los widgets sin audio siguen funcionando
        }
    }

    private fun process(fft: ByteArray, rateMilliHz: Int) {
        val n = Audio.N
        val sampleRate = rateMilliHz / 1000f
        val binHz = sampleRate / fft.size
        val numBins = fft.size / 2
        val fMin = 40f
        val fMax = minOf(12000f, sampleRate / 2f - 1f)
        val bands = Audio.bands

        for (i in 0 until n) {
            val lo = fMin * (fMax / fMin).pow(i / n.toFloat())
            val hi = fMin * (fMax / fMin).pow((i + 1) / n.toFloat())
            val kLo = (lo / binHz).toInt().coerceIn(1, numBins - 1)
            val kHi = (hi / binHz).toInt().coerceIn(kLo, numBins - 1)

            var peak = 0f
            for (k in kLo..kHi) {
                peak = maxOf(peak, hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat()))
            }
            var v = log10(1f + peak) / log10(1f + 150f)
            v = (v * (1f + i * 0.04f)).coerceIn(0f, 1f)
            v = v * v * 1.1f
            val target = (v * n).coerceIn(0f, n.toFloat())

            bands[i] = if (target > bands[i]) bands[i] + (target - bands[i]) * 0.65f
                       else bands[i] * 0.86f
        }
    }

    override fun onDestroy() {
        ticking = false
        handler.removeCallbacksAndMessages(null)
        thread.quitSafely()
        try { unregisterReceiver(unlockRx) } catch (_: Exception) {}
        viz?.apply { enabled = false; release() }
        viz = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
