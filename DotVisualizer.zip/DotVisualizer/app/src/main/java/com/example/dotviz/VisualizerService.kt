package com.example.dotviz

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin

class VisualizerService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.example.dotviz.STOP"
        private const val N = 2048            // muestras por FFT
        private const val SAMPLE_RATE = 44100
    }

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    @Volatile private var running = false
    private var worker: Thread? = null

    private val bands = FloatArray(8)
    private var lastPush = 0L
    private var idleDrawn = false

    private val window = FloatArray(N) { (0.5 - 0.5 * cos(2 * PI * it / (N - 1))).toFloat() }
    private val re = FloatArray(N)
    private val im = FloatArray(N)

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("viz", "Visualizer", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_DATA)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        // Debe llamarse a startForeground (tipo mediaProjection) ANTES de getMediaProjection
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, VisualizerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "viz")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Visualizador activo")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Detener", stopPi
                ).build()
            )
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        stopCapture()
        startCapture(code, data)
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startCapture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val mp = mpm.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, null)
            projection = mp

            val cfg = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()

            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()

            val rec = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(N * 2 * 2 * 4)
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            record = rec
            rec.startRecording()

            running = true
            worker = Thread {
                val buf = ShortArray(N * 2) // estéreo intercalado
                while (running) {
                    val read = rec.read(buf, 0, buf.size)
                    if (read < buf.size) continue
                    for (i in 0 until N) {
                        val mono = (buf[2 * i] + buf[2 * i + 1]) / 65536f // -1..1
                        re[i] = mono * window[i]
                        im[i] = 0f
                    }
                    fft(re, im)
                    analyze()
                }
            }.apply { name = "viz-fft"; start() }
        } catch (e: Exception) {
            e.printStackTrace()
            stopSelf()
        }
    }

    private fun analyze() {
        val binHz = SAMPLE_RATE.toFloat() / N
        val fMin = 50f
        val fMax = 12000f
        val scale = N / 4f // normaliza la amplitud con ventana Hann

        for (i in 0 until 8) {
            val lo = fMin * (fMax / fMin).pow(i / 8f)
            val hi = fMin * (fMax / fMin).pow((i + 1) / 8f)
            val kLo = (lo / binHz).toInt().coerceIn(1, N / 2 - 1)
            val kHi = (hi / binHz).toInt().coerceIn(kLo, N / 2 - 1)

            var peak = 0f
            for (k in kLo..kHi) peak = maxOf(peak, hypot(re[k], im[k]))

            val db = 20f * log10(peak / scale + 1e-6f)          // dBFS
            var v = ((db + 60f) / 50f).coerceIn(0f, 1f)         // -60..-10 dB -> 0..1
            v = (v * (1f + i * 0.05f)).coerceIn(0f, 1f)
            val target = v * 8f

            bands[i] = if (target > bands[i]) bands[i] + (target - bands[i]) * 0.7f
                       else bands[i] * 0.84f
        }

        val now = SystemClock.uptimeMillis()
        if (now - lastPush < 40) return
        val silent = bands.all { it < 0.3f }
        if (silent && idleDrawn) return
        lastPush = now
        idleDrawn = silent
        if (VisualizerWidget.hasWidgets(this)) {
            VisualizerWidget.push(this, if (silent) FloatArray(8) else bands)
        }
    }

    /** FFT radix-2 in-place. */
    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = (-2 * PI / len)
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f; var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val xr = re[b] * cr - im[b] * ci
                    val xi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - xr; im[b] = im[a] - xi
                    re[a] += xr; im[a] += xi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun stopCapture() {
        running = false
        worker?.join(300)
        worker = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
        projection?.stop()
        projection = null
    }

    override fun onDestroy() {
        stopCapture()
        VisualizerWidget.push(this, FloatArray(8))
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
