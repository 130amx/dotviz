package com.example.dotviz

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    override fun onListenerConnected() { Stats.notifLinked = true; refresh() }
    override fun onListenerDisconnected() { Stats.notifLinked = false }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refresh() }

    private fun refresh() {
        Stats.notifCount = try {
            activeNotifications.count { it.isClearable && it.packageName != packageName }
        } catch (e: Exception) { 0 }
    }
}
