package com.example.dotviz

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class VisualizerWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        for (id in ids) {
            val rv = RemoteViews(context.packageName, R.layout.widget_visualizer)
            rv.setImageViewBitmap(R.id.img, DotRenderer.render(SIZE, FloatArray(8)))
            rv.setOnClickPendingIntent(R.id.img, open) // toca el widget = (re)activar el servicio
            manager.updateAppWidget(id, rv)
        }
    }

    companion object {
        const val SIZE = 360

        fun push(context: Context, bands: FloatArray) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, VisualizerWidget::class.java))
            if (ids.isEmpty()) return
            val rv = RemoteViews(context.packageName, R.layout.widget_visualizer)
            rv.setImageViewBitmap(R.id.img, DotRenderer.render(SIZE, bands))
            mgr.partiallyUpdateAppWidget(ids, rv)
        }

        fun hasWidgets(context: Context): Boolean {
            val mgr = AppWidgetManager.getInstance(context)
            return mgr.getAppWidgetIds(ComponentName(context, VisualizerWidget::class.java)).isNotEmpty()
        }
    }
}
