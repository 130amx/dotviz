package com.example.dotviz

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.roundToInt

/** Dibuja la matriz 8x8 de puntos estilo Nothing. bands = 8 valores entre 0 y 8. */
object DotRenderer {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Brillo del punto según su distancia a la punta de la barra (0 = punta)
    private val levels = intArrayOf(255, 205, 130, 115, 75, 62, 62, 62)
    private const val OFF = 0x26

    fun render(size: Int, bands: FloatArray): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        paint.color = Color.rgb(0x1B, 0x1B, 0x1D)
        c.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.17f, size * 0.17f, paint)

        val margin = size * 0.10f
        val cell = (size - 2 * margin) / 8f
        val radius = cell * 0.36f

        for (col in 0 until 8) {
            val lit = bands[col].roundToInt().coerceIn(0, 8)
            for (row in 0 until 8) { // row 0 = abajo
                val g = if (row < lit) levels[(lit - 1 - row).coerceAtMost(7)] else OFF
                paint.color = Color.rgb(g, g, g)
                val cx = margin + cell * (col + 0.5f)
                val cy = size - margin - cell * (row + 0.5f)
                c.drawCircle(cx, cy, radius, paint)
            }
        }
        return bmp
    }
}
